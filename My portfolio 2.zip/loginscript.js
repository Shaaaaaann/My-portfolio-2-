const form = document.getElementById('login-form');

form.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value; // Palitan ang 'username' ng 'email'
    const password = document.getElementById('password').value;

    // Perform authentication (You can add your authentication logic here)
    if (password === 'your_password') { // Palitan ang 'your_username' ng 'your_password'
        // Redirect to the main website upon successful login
        window.location.href = 'login.html';
    } else {
        alert('Invalid email or password. Please try again.'); // Baguhin ang error message
    }
});